/* Adresse du serveur BIBLIO ITA (modifiee par : npm run configurer -- <adresse>) */
window.BIBLIO_SERVEUR = 'http://192.168.1.10/biblio-ita/';
