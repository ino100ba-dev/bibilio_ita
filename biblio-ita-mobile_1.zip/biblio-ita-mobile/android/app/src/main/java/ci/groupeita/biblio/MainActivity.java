package ci.groupeita.biblio;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
