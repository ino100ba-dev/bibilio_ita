/**
 * Change l'adresse du serveur BIBLIO ITA utilisee par l'application mobile.
 *   npm run configurer -- http://192.168.1.10/biblio-ita/
 *   npm run configurer -- https://biblio.ita.ci/
 * Met a jour capacitor.config.json et www/config.js, puis lancer : npx cap sync
 */
const fs = require('fs');
const path = require('path');

let adresse = process.argv[2];
if (!adresse || !/^https?:\/\//.test(adresse)) {
  console.error('Usage : npm run configurer -- http://ADRESSE-DU-SERVEUR/biblio-ita/');
  process.exit(1);
}
if (!adresse.endsWith('/')) adresse += '/';
const u = new URL(adresse);

const fic = path.join(__dirname, '..', 'capacitor.config.json');
const cfg = JSON.parse(fs.readFileSync(fic, 'utf8'));
cfg.server.url = adresse + 'tableau-de-bord.php';
cfg.server.cleartext = u.protocol === 'http:';
cfg.server.allowNavigation = [u.hostname];
fs.writeFileSync(fic, JSON.stringify(cfg, null, 2) + '\n');

fs.writeFileSync(path.join(__dirname, '..', 'www', 'config.js'),
  "/* Adresse du serveur BIBLIO ITA (modifiee par : npm run configurer -- <adresse>) */\n" +
  "window.BIBLIO_SERVEUR = " + JSON.stringify(adresse) + ";\n");

console.log('Serveur configure :', adresse);
console.log('Etape suivante : npx cap sync   puis   npx cap open android');
